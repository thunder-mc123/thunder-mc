# Thunder MC Premium Website

## Files
- index.html — main website
- style.css — premium dark/storm design
- script.js — animations, counters, mobile menu and copy-IP button

## Run
Open `index.html` in a browser.

## Put online for free
Upload the three files to a GitHub repository and enable GitHub Pages.

## Change Discord
In `index.html`, replace `https://discord.com` with your real Discord invite.

## Change server IP
The current IP is:
thundermcs1.play.minekube.net

If your IP changes, update `SERVER_IP` in `script.js` and the visible IP in `index.html`.
